This package contains the generated API stubs for
[CodeChecker](https://github.com/Ericsson/codechecker).  
[Apache Thrift](https://thrift.apache.org/) is used to generate the stubs.
